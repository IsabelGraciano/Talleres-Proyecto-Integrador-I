from django.apps import AppConfig


class MeasureConfig(AppConfig):
    name = 'measure'
