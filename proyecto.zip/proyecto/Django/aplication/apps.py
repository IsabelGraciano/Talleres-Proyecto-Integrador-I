from django.apps import AppConfig


class AplicationConfig(AppConfig):
    name = 'aplication'
